import CreateMLUI

/*~~~~
 This section is for image classification
~~~~*/
let builder = MLImageClassifierBuilder()
builder.showInLiveView()
